#ifndef PLUGIN_H
#define PLUGIN_H

/*
  TODO: This file was intended to be a temporary stub. We should think
  of getting rid of it. This would entail including "options/plugin.h"
  instead and explicitly using the options namespace. See also option_parser.h,
  option_parser_util.h and issue588 for a discussion.
*/
#include "options/plugin.h"

using options::Plugin;
using options::PluginGroupPlugin;
using options::PluginTypePlugin;

#endif
